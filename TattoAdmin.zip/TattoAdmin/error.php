<!DOCTYPE html>
<html>
<head>
    <title>Token Already Used</title>
</head>
<body>
    <h1>Error: Token Already Used</h1>
    <p>The password reset token you provided has already been used. Please request a new password reset token.</p>
</body>
</html>
