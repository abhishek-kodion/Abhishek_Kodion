<?php include 'includes/header.php' ?>

<style>
    .card-img-top {
    width: 100%;
    height: 15vw;
    object-fit: cover;
}
</style>
<div class="wrapper">
    <?php include 'includes/sidebar.php'; ?>

    <main id="main" class="main">

        <!-- web stats to be added  -->

    </main>

    <?php include 'includes/footer.php'; ?>
</div>