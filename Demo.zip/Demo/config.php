<?php 
$conn = mysqli_connect('localhost', 'root', '', 'tatto_blazers');
?>