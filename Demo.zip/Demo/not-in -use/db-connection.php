<?php
// $connection = mysqli_connect('localhost','root',''); //connect to localhost

// $cr_db = "CREATE DATABASE`task`"; //create databse
// $run = mysqli_query($connection,$cr_db);

$connection_db = mysqli_connect('localhost','root','','task'); //database connection 
?>