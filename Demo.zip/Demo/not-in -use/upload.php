<form action="file.php" method="post" enctype="multipart/form-data">
<input type="file" name="uploadfile" id="">
<button type="submit" name="submit">submit</button>
</form> 