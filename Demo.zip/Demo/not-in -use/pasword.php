<html>
    <head>
        <title>
            password check
        </title>
    </head>
    <style>
        .container
        {
            margin-left: 646px;
            margin-top: 150px;

        }
    </style>
    <body>
        <div class="container">
            <form action="test-password.php" method="post">
        password <br>
        <input type="password" name="password" id="">
        <br>
        <!-- conform password <br>
        <input type="password" name="cpassword" id="">
        <br> -->
        <br>
        <button type="submit" name="submit"> submit</button>
        </form>
        </div>
    </body>
</html>